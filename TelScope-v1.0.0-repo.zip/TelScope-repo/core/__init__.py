# TelScope core package (MIT)
